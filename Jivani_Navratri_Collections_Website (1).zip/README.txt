JIVANI NAVRATRI COLLECTIONS - WEBSITE

Open index.html in Chrome/Edge to preview the website.

To customize products:
1. Open index.html in a text editor.
2. Find "YOUR PHOTO HERE", "YOUR PRICE", product names and sizes.
3. Replace them with your actual information.
4. For actual product photos, replace each product photo block with an <img> tag, or ask me to update the site after you upload the photos.

WhatsApp number is already connected to 7058548070.
Shop location shown:
Kids Wear, Opp. Shalimar
Swatantra Path
Vasco da Gama, Goa

Delivery note: charges are applied according to customer location.

This is a static website. It does not process online payments or automatically calculate delivery charges yet.
